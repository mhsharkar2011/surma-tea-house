<div class="container-fluid testimonial py-5 my-5" id="testimonial.php">
        <div class="container py-5">
            <div class="section-title text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style="max-width: 800px;">
                <p class="fs-5 fw-medium fst-italic text-white">Testimonial</p>
                <h3 class="display-6">What our <span class="text-white">Clients</span> say about our <span class="text-white">Tea</span></h3>
            </div>
            <div class="owl-carousel testimonial-carousel wow fadeInUp" data-wow-delay="0.5s">
               <?php 
                    for($i = 0; $i<3; $i++){
                        echo "<div class='testimonial-item p-4 p-lg-5'>
                        <p class='mb-4'>Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo</p>
                        <div class='d-flex align-items-center justify-content-center'>
                            <img class='img-fluid flex-shrink-0' src='img/testimonial-1.jpg' alt=''>
                            <div class='text-start ms-3'>
                                <h5>Client Name</h5>
                                <span class='text-primary'>Profession</span>
                            </div>
                        </div>
                    </div>";
                    }
               ?>
            </div>
        </div>
    </div>